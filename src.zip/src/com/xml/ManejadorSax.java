package com.xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.modelo.Restaurante;
import com.modelo.ResumenLectura;

public class ManejadorSax extends DefaultHandler {

	private final boolean mostrar;
	private Restaurante actual;
	private final StringBuilder texto;
	private final ResumenLectura resumen;

	public ManejadorSax(boolean mostrar)
	{
		this.mostrar = mostrar;
		this.texto = new StringBuilder();
		this.resumen = new ResumenLectura();
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes)
			throws SAXException
	{
		texto.setLength(0);

		if (qName.equals("restaurante"))
		{
			actual = new Restaurante();
			actual.setId(Integer.parseInt(attributes.getValue("id")));
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException
	{
		texto.append(ch, start, length);
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException
	{
		String valor = texto.toString().trim();

		switch (qName)
		{
			case "nombre" -> actual.setNombre(valor);
			case "direccion" -> actual.setDireccion(valor);
			case "codigoPostal" -> actual.setCodigoPostal(valor);
			case "tipoCocina" -> actual.setTipoCocina(valor);
			case "puntuacion" -> actual.setPuntuacion(Double.parseDouble(valor));
			case "restaurante" ->
			{
				if (mostrar)
				{
					System.out.println(actual);
				}
				resumen.anhadir(actual);
			}
		}
	}

	public ResumenLectura getResumen()
	{
		return resumen;
	}
}