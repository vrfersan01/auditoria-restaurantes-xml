package com.modelo;

import java.util.Locale;

public class Restaurante {
	
	private int id;
	private String nombre;
	private String direccion;
	private String codigoPostal;
	private String tipoCocina;
	private double puntuacion;
	
	public Restaurante()
	{
		
	}

	public Restaurante(int id, String nombre, String direccion, String codigoPostal, String tipoCocina,
			double puntuacion) {
		
		this.id = id;
		this.nombre = nombre;
		this.direccion = direccion;
		this.codigoPostal = codigoPostal;
		this.tipoCocina = tipoCocina;
		this.puntuacion = puntuacion;
	}

	
	public String puntuacionTexto()
	{		
		return String.format(Locale.US, "%.1f", this.puntuacion);
	}

	public boolean mismoNombreYDireccion(Restaurante otro)
	{
		return otro.getNombre().equalsIgnoreCase(this.nombre) 
				&& otro.getDireccion().equalsIgnoreCase(this.direccion);
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getCodigoPostal() {
		return codigoPostal;
	}
	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}
	public String getTipoCocina() {
		return tipoCocina;
	}
	public void setTipoCocina(String tipoCocina) {
		this.tipoCocina = tipoCocina;
	}
	public double getPuntuacion() {
		return puntuacion;
	}
	public void setPuntuacion(double puntuacion) {
		this.puntuacion = puntuacion;
	}

	@Override
	public String toString() {
		return id + " | " + nombre + " | " + direccion + " | "
				+ codigoPostal + " | " + tipoCocina + " | " + puntuacionTexto();
	}
	
	
}

/*
nombre,direccion,codigo_postal,tipo_cocina,puntuacion
*/