package com.app;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

import com.csv.GestorCsv;
import com.csv.Validador;
import com.ficheros.GestorFicheros;
import com.ficheros.ResultadoComparacion;
import com.informes.Estadisticas;
import com.informes.Rendimiento;
import com.modelo.Filtro;
import com.modelo.Incidencia;
import com.modelo.Restaurante;
import com.modelo.ResultadoCarga;
import com.modelo.ResultadoValidacion;
import com.modelo.ResumenLectura;
import com.xml.GestorDom;
import com.xml.GestorSax;

public class Main {

	private static List<Restaurante>restaurantes = new ArrayList<>();
	
	private static final String RUTA_SUCIO = "datos/restaurantes_sucio.csv";
	private static final String RUTA_LIMPIO = "salida/restaurantes_limpio.csv";
	private static final String RUTA_ERRORES = "errores/errores.txt";
	private static final String RUTA_AVISOS = "errores/avisos.txt";
	private static final String RUTA_XML = "salida/Restaurantes.xml";
	private static final String RUTA_CSV_XML = "salida/restaurantes_desde_xml.csv";
	private static final String RUTA_ESTADISTICAS = "salida/estadisticas.txt";
	
	private static final String RUTA_GRANDE = "datos/restaurantes_grande.csv";
	private static final String RUTA_XML_GRANDE = "salida/grande.xml";
	private static final String RUTA_RENDIMIENTO = "salida/rendimiento.txt";
	
	
	public static void main(String[] args) {
 
		boolean salir = false;
		int opcion = -1;
		while (!salir)
		{
			mostrarMenu();
			
			//-----------------MODIFICAR MÍNIMO AL AÑADIR UNA OPCIÓN NUEVA----------------------//
			opcion = Teclado.leerEntero("Opción: ", 0, 12);
			try
			{
				salir = ejecutarMenu(opcion);
			}
			catch (IOException e)
			{
				System.out.println("Error de lectura o escritura: " + e.getMessage());
			}
			catch (SAXException | ParserConfigurationException e)
			{
				System.out.println("Error al procesar el XML: " + e.getMessage());
			}
			catch (Exception e)
			{
				System.out.println("Error inesperado: " + e.getMessage());
			}
		}
		
		//CIERRA EL SCANNER
		Teclado.cerrar();
		

	}
	
	private static void mostrarMenu()
	{
		System.out.println("\n===== GESTOR DE RESTAURANTES =====");
		System.out.println("1. Preparar entorno y hacer copia de seguridad");
		System.out.println("2. Cargar y limpiar CSV");
		System.out.println("3. Consultar restaurantes");
		System.out.println("4. Añadir restaurante");
		System.out.println("5. Modificar restaurante");
		System.out.println("6. Eliminar restaurante");
		System.out.println("7. Exportar a XML (DOM)");
		System.out.println("8. Leer XML con DOM");
		System.out.println("9. Leer XML con SAX");
		System.out.println("10. Convertir XML a CSV y verificar integridad");
		System.out.println("11. Estadísticas");
		System.out.println("12. Comparar rendimiento DOM vs SAX");
		System.out.println("0. Salir");
	}
	
	private static boolean ejecutarMenu(int opcion) throws IOException, SAXException, ParserConfigurationException
	{
		boolean salir = false;

		if (opcion == 0)
		{
			salir = true;
		}
		
		//-----------INCLUIR SI OPCION NECESITA DATOS (hayDatos() solo mira si 
		//---------------la lista restaurante no está vacía------------------//
		
		else if (necesitaDatos(opcion) && !hayDatos()) 
			//si es de las opciones que necesitan datos comprueba 
			//si hay datos cargados
		{
			System.out.println("Primero carga el CSV con la opción 2.");
		}
		else
		{
			switch (opcion)
			{
			case 1 -> opcionEntorno();
			case 2 -> opcionCargar();
			case 3 -> opcionConsultar();
			case 4 -> opcionAnhadir();
			case 5 -> opcionModificar();
			case 6 -> opcionEliminar();
			case 7 -> opcionExportar();
			case 8 -> opcionLeerDom();
			case 9 -> opcionLeerSax();
			case 10 -> opcionIntegridad();
			case 11 -> opcionEstadisticas();
			case 12 -> opcionRendimiento();
			}
		}
		return salir;
	}

	
	private static boolean hayDatos()
	{
		return !restaurantes.isEmpty();
	}

	private static boolean necesitaDatos(int opcion)
	{
		return (opcion >= 3 && opcion <= 7) || opcion == 11;
	}

	private static void opcionEntorno() throws IOException
	{
		List<String> mensajes = GestorFicheros.prepararEntorno();
		for(String s:mensajes)
			System.out.println(s);
		
		File csv = new File(RUTA_SUCIO);
		System.out.println(GestorFicheros.infoFichero(csv));
		
		//HACE LA COPIA DEL CSV "SUCIO" SI SE PUEDE. PARA COPIAR OTRO REPETIR PROCESO
		if(csv.isFile() && csv.canRead())
		{
			File copia = GestorFicheros.copiaConMarcaTiempo(csv, "copias");
			System.out.println("Copia creada: " + copia.getPath());
			
			if(copia.length() == csv.length())
			{
				System.out.println("Copia verificada: mismo tamaño");
			}
			else
				System.out.println("ERROR: la copia tiene distinto tamaño");
		}
		else
			System.out.println("No se puede hacer la copia: falta el fichero o no se puede leer");
	}

	private static void opcionCargar() throws IOException
	{
		GestorFicheros.prepararEntorno();

	    ResultadoCarga resultado = GestorCsv.cargar(RUTA_SUCIO);
	    restaurantes = resultado.getRestaurantes();

	    GestorCsv.escribir(restaurantes, RUTA_LIMPIO);
	    GestorCsv.escribirIncidencias(resultado.getErrores(), RUTA_ERRORES);
	    GestorCsv.escribirIncidencias(resultado.getAvisos(), RUTA_AVISOS);

	    System.out.println(resultado.resumen());

	    if (resultado.cuadra())
	    {
	        System.out.println("Comprobación correcta: leídas - vacías = válidas + rechazadas");
	    }
	    else
	    {
	        System.out.println("ERROR: las filas no cuadran, revisa el programa");
	    }
	}

	private static void opcionConsultar()
	{
		 Filtro filtro = MenuFiltro.pedir(false);
		 List<Restaurante> resultado = filtro.aplicar(restaurantes);

		 //Ordena la lista resultado de mayor a menor puntuación.
		 resultado.sort((a, b) -> Double.compare(b.getPuntuacion(), a.getPuntuacion()));

		 System.out.println("Filtro: " + filtro.descripcion());

		 for (Restaurante r : resultado)
		 {
		        System.out.println(r);
		 }

		 System.out.println("Coincidencias: " + resultado.size());
	}

	private static void opcionAnhadir() throws IOException
	{
	    boolean terminado = false;

	    while (!terminado)
	    {
	        String nombre = Teclado.leerTexto("Nombre: ");
	        String direccion = Teclado.leerTexto("Dirección: ");
	        String cp = Teclado.leerTexto("Código postal: ");
	        String cocina = Teclado.leerTexto("Tipo de cocina: ");
	        String puntuacion = Teclado.leerTexto("Puntuación: ");

	        List<String> campos = List.of(nombre, direccion, cp, cocina, puntuacion);
	        String original = String.join(",", campos);
	        
	        ResultadoValidacion resultado = Validador.validar(campos, 0, original, restaurantes, -1);

	        if (resultado.esValido())
	        {
	            for (Incidencia aviso : resultado.getAvisos())
	            {
	                System.out.println("Corregido: " + aviso.getMensaje());
	            }

	            Restaurante nuevo = resultado.getRestaurante();
	            nuevo.setId(siguienteId());
	            restaurantes.add(nuevo);

	            if (GestorCsv.guardarSeguro(restaurantes, RUTA_LIMPIO))
	            {
	                System.out.println("Restaurante añadido con id " + nuevo.getId());
	            }
	            else
	            {
	                restaurantes.remove(nuevo);
	                System.out.println("ERROR: no se ha podido guardar, no se ha añadido nada.");
	            }
	            terminado = true;
	        }
	        else
	        {
	            System.out.println("Error: " + resultado.getError().getMensaje());
	            terminado = !Teclado.confirmar("¿Quieres intentarlo de nuevo?");
	        }
	    }
	}

	private static int siguienteId()
	{
	    int maximo = 0;

	    for (Restaurante r : restaurantes)
	    {
	        if (r.getId() > maximo)
	        {
	            maximo = r.getId();
	        }
	    }

	    return maximo + 1;
	}

	private static void opcionModificar() throws IOException
	{
	    int id = Teclado.leerEntero("Id del restaurante a modificar: ", 1, Integer.MAX_VALUE);
	    Restaurante antiguo = buscarPorId(id);

	    if (antiguo == null)
	    {
	        System.out.println("No existe ningún restaurante con id " + id);
	    }
	    else
	    {
	        System.out.println(antiguo);
	        boolean terminado = false;

	        while (!terminado)
	        {
	            String nombre = Teclado.leerTextoODefecto("Nombre", antiguo.getNombre());
	            String direccion = Teclado.leerTextoODefecto("Dirección", antiguo.getDireccion());
	            String cp = Teclado.leerTextoODefecto("Código postal", antiguo.getCodigoPostal());
	            String cocina = Teclado.leerTextoODefecto("Tipo de cocina", antiguo.getTipoCocina());
	            String puntuacion = Teclado.leerTextoODefecto("Puntuación", antiguo.puntuacionTexto());

	            List<String> campos = List.of(nombre, direccion, cp, cocina, puntuacion);
	            String original = String.join(",", campos);
	            ResultadoValidacion resultado =
	                    Validador.validar(campos, 0, original, restaurantes, id);

	            if (resultado.esValido())
	            {
	                Restaurante nuevo = resultado.getRestaurante();
	                nuevo.setId(id);
	                int indice = restaurantes.indexOf(antiguo);
	                restaurantes.set(indice, nuevo);

	                if (GestorCsv.guardarSeguro(restaurantes, RUTA_LIMPIO))
	                {
	                    System.out.println("Restaurante " + id + " modificado");
	                }
	                else
	                {
	                    restaurantes.set(indice, antiguo);
	                    System.out.println("ERROR: no se ha podido guardar, no se ha modificado nada.");
	                }
	                terminado = true;
	            }
	            else
	            {
	                System.out.println("Error: " + resultado.getError().getMensaje());
	                terminado = !Teclado.confirmar("¿Quieres intentarlo de nuevo?");
	            }
	        }
	    }
	}

	private static Restaurante buscarPorId(int id)
	{
	    Restaurante encontrado = null;

	    for (int i = 0; i < restaurantes.size() && encontrado == null; ++i)
	    {
	        if (restaurantes.get(i).getId() == id)
	        {
	            encontrado = restaurantes.get(i);
	        }
	    }

	    return encontrado;
	}

	private static void opcionEliminar() throws IOException
	{
	    int id = Teclado.leerEntero("Id del restaurante a eliminar: ", 1, Integer.MAX_VALUE);
	    Restaurante eliminado = buscarPorId(id);

	    if (eliminado == null)
	    {
	        System.out.println("No existe ningún restaurante con id " + id);
	    }
	    else
	    {
	        System.out.println(eliminado);

	        if (Teclado.confirmar("¿Seguro que quieres eliminarlo?"))
	        {
	            int indice = restaurantes.indexOf(eliminado);
	            restaurantes.remove(indice);

	            if (GestorCsv.guardarSeguro(restaurantes, RUTA_LIMPIO))
	            {
	                System.out.println("Restaurante " + id + " eliminado");
	            }
	            else
	            {
	                restaurantes.add(indice, eliminado);
	                System.out.println("ERROR: no se ha podido guardar, no se ha eliminado nada.");
	            }
	        }
	        else
	        {
	            System.out.println("Operación cancelada.");
	        }
	    }
	}

	private static void opcionExportar() throws ParserConfigurationException
	{
	    Filtro filtro = MenuFiltro.pedir(true);
	    String ruta = Teclado.leerTextoODefecto("Fichero de salida", RUTA_XML);

	    List<Restaurante> seleccionados = filtro.aplicar(restaurantes);
	    int escritos = GestorDom.exportar(seleccionados, ruta);

	    System.out.println("Exportados " + escritos + " restaurantes a " + ruta);
	}

	private static void opcionLeerDom() throws ParserConfigurationException, SAXException, IOException
	{
	    String ruta = Teclado.leerTextoODefecto("Fichero XML", RUTA_XML);
	    List<Restaurante> lista = GestorDom.leer(ruta);

	    for (Restaurante r : lista)
	    {
	        System.out.println(r);
	    }

	    System.out.println(ResumenLectura.desdeLista(lista));
	}

	private static void opcionLeerSax() throws ParserConfigurationException, SAXException, IOException
	{
	    String ruta = Teclado.leerTextoODefecto("Fichero XML", RUTA_XML);
	    ResumenLectura resumen = GestorSax.leer(ruta, true);

	    System.out.println(resumen);
	}

	private static void opcionIntegridad()
	        throws ParserConfigurationException, SAXException, IOException {
	    List<Restaurante> desdeXml = GestorDom.leer(RUTA_XML);
	    GestorCsv.escribir(desdeXml, RUTA_CSV_XML);
	    ResultadoComparacion resultado = GestorFicheros.comparar(RUTA_LIMPIO, RUTA_CSV_XML);
	    System.out.println(resultado.informe());
	}

	private static void opcionEstadisticas() throws IOException {
	    String texto = Estadisticas.generar(restaurantes);
	    System.out.println(texto);
	    GestorFicheros.escribirTexto(RUTA_ESTADISTICAS, texto);
	    System.out.println("Estadísticas guardadas en " + RUTA_ESTADISTICAS);
	}

	private static void opcionRendimiento()
	        throws ParserConfigurationException, SAXException, IOException {
	    GestorFicheros.prepararEntorno();

	    System.out.println("Cargando el CSV grande (puede tardar)...");
	    ResultadoCarga carga = GestorCsv.cargar(RUTA_GRANDE);
	    GestorDom.exportar(carga.getRestaurantes(), RUTA_XML_GRANDE);

	    System.out.println("Midiendo DOM y SAX...");
	    String tabla = Rendimiento.tabla(Rendimiento.comparar(RUTA_XML_GRANDE));

	    System.out.println(tabla);
	    GestorFicheros.escribirTexto(RUTA_RENDIMIENTO, tabla);
	    System.out.println("Resultados guardados en " + RUTA_RENDIMIENTO);
	}
}


