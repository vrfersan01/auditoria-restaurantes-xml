package com.app;

import com.modelo.Filtro;

public class MenuFiltro {

	public static Filtro pedir(boolean permitirSinFiltro)
	{
		Filtro filtro = new Filtro();
		int maximo = 4;

		if (permitirSinFiltro)
		{
			maximo = 5;
		}

		mostrarOpciones(permitirSinFiltro);
		int opcion = Teclado.leerEntero("Opción de filtro: ", 1, maximo);

		if (opcion <= 3)
		{
			aplicarCriterio(filtro, opcion);
		}
		else if (opcion == 4)
		{
			pedirCombinacion(filtro);
		}

		return filtro;
	}

	private static void mostrarOpciones(boolean permitirSinFiltro)
	{
		System.out.println("1. Código postal que empieza por...");
		System.out.println("2. Tipo de cocina");
		System.out.println("3. Puntuación mayor que...");
		System.out.println("4. Combinación de dos condiciones");

		if (permitirSinFiltro)
		{
			System.out.println("5. Sin filtro (todos)");
		}
	}

	private static void pedirCombinacion(Filtro filtro)
	{
		int primero = Teclado.leerEntero("Primer criterio (1-3): ", 1, 3);
		int segundo = Teclado.leerEntero("Segundo criterio (1-3): ", 1, 3);

		while (segundo == primero)
		{
			System.out.println("Tiene que ser distinto del primero.");
			segundo = Teclado.leerEntero("Segundo criterio (1-3): ", 1, 3);
		}

		aplicarCriterio(filtro, primero);
		aplicarCriterio(filtro, segundo);
	}

	private static void aplicarCriterio(Filtro filtro, int criterio)
	{
		switch (criterio)
		{
			case 1 -> filtro.setPrefijoCp(Teclado.leerTexto("Código postal empieza por: "));
			case 2 -> filtro.setTipoCocina(Teclado.leerTexto("Tipo de cocina: "));
			case 3 -> filtro.setPuntuacionMinima(Teclado.leerDouble("Puntuación mayor que: "));
		}
	}
}