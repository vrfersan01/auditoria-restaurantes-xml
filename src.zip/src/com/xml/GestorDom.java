package com.xml;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.modelo.Restaurante;

public class GestorDom {
	
	public static int exportar(List<Restaurante> lista, String ruta) throws ParserConfigurationException
	{
		int restaurantesEscritos = 0;
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = builder.newDocument();
		
		Element raiz = doc.createElement("restaurantes");
		doc.appendChild(raiz);
		
		for(Restaurante r:lista)
		{
			Element e = doc.createElement("restaurante");
			e.setAttribute("id", String.valueOf(r.getId()));
			crearHijo(doc,e,"nombre",r.getNombre());
			crearHijo(doc,e,"direccion",r.getDireccion());
			crearHijo(doc,e,"codigoPostal",r.getCodigoPostal());
			crearHijo(doc,e,"tipoCocina",r.getTipoCocina());
			crearHijo(doc,e,"puntuacion",r.puntuacionTexto());
			++restaurantesEscritos;
			raiz.appendChild(e);
		}
		
		try {
			guardarXML(doc,ruta);
			System.out.println("Archivo guardao con éxito");
		} catch (TransformerFactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return restaurantesEscritos;
	}
	
	private static void crearHijo(Document doc, Element padre, String etiqueta, String valor)
	{
		 Element e = doc.createElement(etiqueta);
		 padre.appendChild(e);
		 e.setTextContent(valor);
	}
	
	private static void guardarXML(Document doc, String ruta) throws TransformerFactoryConfigurationError, TransformerException
	{
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		transformer.transform(new DOMSource(doc), new StreamResult(new File(ruta)));
	}
	
	private static String valor(Element e, String etiqueta)
	{
	    String resultado = "";
	    NodeList nodos = e.getElementsByTagName(etiqueta);

	    if (nodos.getLength() > 0)
	    {
	        resultado = nodos.item(0).getTextContent().trim();
	    }

	    return resultado;
	}
	
	public static List<Restaurante> leer(String ruta)
	        throws ParserConfigurationException, SAXException, IOException
	{
	    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    Document doc = builder.parse(new File(ruta));

	    List<Restaurante> lista = new ArrayList<>();
	    NodeList nodos = doc.getElementsByTagName("restaurante");

	    for (int i = 0; i < nodos.getLength(); ++i)
	    {
	        Element e = (Element) nodos.item(i);
	        Restaurante r = new Restaurante(
	                Integer.parseInt(e.getAttribute("id")),
	                valor(e, "nombre"),
	                valor(e, "direccion"),
	                valor(e, "codigoPostal"),
	                valor(e, "tipoCocina"),
	                Double.parseDouble(valor(e, "puntuacion")));
	        lista.add(r);
	    }

	    return lista;
	}
	
}
