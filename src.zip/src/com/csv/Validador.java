package com.csv;

import java.util.ArrayList;
import java.util.List;

import com.modelo.Incidencia;
import com.modelo.Restaurante;
import com.modelo.ResultadoValidacion;

public class Validador {

	public static ResultadoValidacion validar(List<String> campos, int linea, String original,
	        List<Restaurante> aceptados, int idIgnorar)
	{
	    List<Incidencia> avisos = new ArrayList<>();
	    Incidencia error = null;
	    Restaurante restaurante = null;

	    if (campos.size() != 5)
	    {
	        error = new Incidencia(linea, "E01",
	                "La fila no tiene 5 campos (tiene " + campos.size() + ")", original);
	    }
	    else
	    {
	        String nombre = campos.get(0);
	        String direccion = campos.get(1);
	        String cp = campos.get(2);
	        String cocina = campos.get(3);
	        String textoPuntuacion = campos.get(4);
	        double puntuacion = 0;

	        if (nombre.isEmpty())
	        {
	            error = new Incidencia(linea, "E02", "El nombre está vacío", original);
	        }

	        if (error == null)
	        {
	            String corregido = corregirCodigoPostal(cp);

	            if (!corregido.equals(cp))
	            {
	                avisos.add(new Incidencia(linea, "W01",
	                        "Código postal corregido: \"" + cp + "\" -> \"" + corregido + "\"", ""));
	                cp = corregido;
	            }
	        }

	        if (error == null && !codigoPostalValido(cp))
	        {
	            error = new Incidencia(linea, "E03",
	                    "Código postal inválido: \"" + cp + "\"", original);
	        }

	        if (error == null)
	        {
	            String corregido = corregirPuntuacion(textoPuntuacion);

	            if (!corregido.equals(textoPuntuacion))
	            {
	                avisos.add(new Incidencia(linea, "W02",
	                        "Puntuación con coma decimal corregida: \"" + textoPuntuacion
	                        + "\" -> \"" + corregido + "\"", ""));
	                textoPuntuacion = corregido;
	            }

	            try
	            {
	                puntuacion = Double.parseDouble(textoPuntuacion);
	            }
	            catch (NumberFormatException e)
	            {
	                error = new Incidencia(linea, "E04",
	                        "La puntuación no es un número: \"" + textoPuntuacion + "\"", original);
	            }
	        }

	        if (error == null && !(puntuacion >= 0 && puntuacion <= 10))
	        {
	            error = new Incidencia(linea, "E05",
	                    "Puntuación fuera de rango: \"" + textoPuntuacion + "\"", original);
	        }

	        if (error == null && cocina.isEmpty())
	        {
	            error = new Incidencia(linea, "E06", "El tipo de cocina está vacío", original);
	        }

	        if (error == null)
	        {
	            String corregido = normalizarCocina(cocina);

	            if (!corregido.equals(cocina))
	            {
	                avisos.add(new Incidencia(linea, "W03",
	                        "Tipo de cocina normalizado: \"" + cocina + "\" -> \"" + corregido + "\"", ""));
	                cocina = corregido;
	            }
	        }

	        if (error == null)
	        {
	            Restaurante candidato = new Restaurante(0, nombre, direccion, cp, cocina, puntuacion);

	            if (esDuplicado(candidato, aceptados, idIgnorar))
	            {
	                error = new Incidencia(linea, "E07",
	                        "Restaurante duplicado: \"" + nombre + "\" en \"" + direccion + "\"", original);
	            }
	            else
	            {
	                restaurante = candidato;
	            }
	        }
	    }

	    if (error != null)
	    {
	        avisos = new ArrayList<>();
	    }

	    return new ResultadoValidacion(restaurante, error, avisos);
	}
	
	private static boolean soloDigitos(String t)
	{
	    boolean correcto = true;

	    for (int i = 0; i < t.length() && correcto; ++i)
	    {
	        char c = t.charAt(i);

	        if (c < '0' || c > '9')
	        {
	            correcto = false;
	        }
	    }

	    return correcto;
	}
	
	private static String corregirCodigoPostal(String cp)
	{
		String cpCorregido = cp;
		if(cp.length() == 4 && soloDigitos(cp))
		{
			cpCorregido = "0"+cp;
		}
		return cpCorregido;
	}
	
	//si empieza por minuscula devuelve empieza por mayuscula
	private static String normalizarCocina(String t)
	{
	    String inicial = t.substring(0, 1).toUpperCase();
	    String resto = t.substring(1).toLowerCase();

	    return inicial + resto;
	}
	
	private static boolean esDuplicado(Restaurante r, List<Restaurante> aceptados, int idIgnorar)
	{
	    boolean duplicado = false;

	    for (int i = 0; i < aceptados.size() && !duplicado; ++i)
	    {
	        Restaurante existente = aceptados.get(i);

	        if (existente.getId() != idIgnorar && existente.mismoNombreYDireccion(r))
	        {
	            duplicado = true;
	        }
	    }

	    return duplicado;
	}
	
	private static boolean codigoPostalValido(String cp)
	{
		boolean valido = false;
		if(cp.length() == 5 && soloDigitos(cp))
		{
			int provincia = Integer.parseInt(cp.substring(0,2));
			valido = provincia >=1 && provincia <=52;
		}
		
		return valido;
	}
	
	private static String corregirPuntuacion(String t)
	{
		return t.replace(',', '.');
	}
}
