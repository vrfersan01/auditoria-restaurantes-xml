package com.modelo;

import java.util.ArrayList;
import java.util.List;

public class Filtro {

	private String prefijoCp;
	private String tipoCocina;
	private Double puntuacionMinima;

	public void setPrefijoCp(String prefijoCp) {
		this.prefijoCp = prefijoCp;
	}

	public void setTipoCocina(String tipoCocina) {
		this.tipoCocina = tipoCocina;
	}

	public void setPuntuacionMinima(Double puntuacionMinima) {
		this.puntuacionMinima = puntuacionMinima;
	}

	public boolean cumple(Restaurante r) {
		boolean ok = true;

		if (prefijoCp != null && !r.getCodigoPostal().startsWith(prefijoCp)) {
			ok = false;
		}
		if (tipoCocina != null && !r.getTipoCocina().equalsIgnoreCase(tipoCocina)) {
			ok = false;
		}
		if (puntuacionMinima != null && !(r.getPuntuacion() > puntuacionMinima)) {
			ok = false;
		}

		return ok;
	}

	public List<Restaurante> aplicar(List<Restaurante> lista) {
		List<Restaurante> resultado = new ArrayList<>();

		for (Restaurante r : lista) {
			if (cumple(r)) {
				resultado.add(r);
			}
		}

		return resultado;
	}

	public String descripcion() {
		List<String> partes = new ArrayList<>();
		String texto;

		if (prefijoCp != null) {
			partes.add("CP empieza por " + prefijoCp);
		}
		if (tipoCocina != null) {
			partes.add("cocina " + tipoCocina);
		}
		if (puntuacionMinima != null) {
			partes.add("puntuación mayor que " + puntuacionMinima);
		}

		if (partes.isEmpty()) {
			texto = "Sin filtro";
		} else {
			texto = String.join(" y ", partes);
		}

		return texto;
	}
}